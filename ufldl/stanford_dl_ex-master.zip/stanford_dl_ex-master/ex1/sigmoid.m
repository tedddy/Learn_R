function h=sigmoid(a)
  h=1./(1+exp(-a));
